package org.hvtra.orderservice.outbox.service;

import lombok.RequiredArgsConstructor;
import org.hvtra.commonservice.kafka.outbox.dto.OutboxSaveCommand;
import org.hvtra.commonservice.kafka.outbox.service.OutboxEventService;
import org.hvtra.orderservice.domain.entity.Order;
import org.hvtra.orderservice.domain.entity.OrderOutboxEvent;
import org.hvtra.orderservice.outbox.event.OrderEventType;
import org.hvtra.orderservice.outbox.resolver.OrderOutboxTopicResolver;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderOutboxPublisher {

    private static final String SOURCE = "order-service";
    private static final String AGGREGATE_TYPE = "ORDER";

    private final OutboxEventService<OrderOutboxEvent> orderOutboxEventService;
    private final OrderOutboxTopicResolver orderOutboxTopicResolver;

    public void publishPaymentCompletedOrchestration(Order order, String paymentEventId) {
        publish(order, OrderEventType.ORDER_COMPLETED, paymentEventId, "order-completed");
        publish(order, OrderEventType.INVENTORY_RESERVATION_CONFIRM_REQUESTED, paymentEventId, "inventory-confirm");

        if (order.getCustomerId() != null) {
            publish(order, OrderEventType.CUSTOMER_PURCHASE_UPDATE_REQUESTED, paymentEventId, "customer-purchase-update");
        }

        if (defaultZero(order.getDiscountAmount()).compareTo(BigDecimal.ZERO) > 0) {
            publish(order, OrderEventType.PROMOTION_USAGE_COMMIT_REQUESTED, paymentEventId, "promotion-commit");
        }
    }

    private void publish(Order order, String eventType, String causationId, String action) {
        String orderId = order.getId().toString();
        String businessKey = orderId + ":" + action;
        String topic = orderOutboxTopicResolver.resolveTopic(eventType);
        String eventId = UUID.randomUUID().toString();
        Map<String, Object> payload = buildPayload(order, eventId, eventType, causationId);

        orderOutboxEventService.saveEventIfAbsent(new OutboxSaveCommand(
                eventId,
                AGGREGATE_TYPE,
                orderId,
                orderId,
                eventType,
                businessKey,
                topic,
                SOURCE,
                null,
                orderId,
                causationId,
                payload,
                buildHeaders(order, eventId, eventType, businessKey, topic, causationId)
        ));
    }

    private Map<String, Object> buildPayload(Order order, String eventId, String eventType, String causationId) {
        Map<String, Object> payload = new LinkedHashMap<>();

        payload.put("eventId", eventId);
        payload.put("eventType", eventType);
        payload.put("eventKey", order.getId().toString());
        payload.put("orderId", order.getId().toString());
        payload.put("orderCode", order.getOrderCode());
        payload.put("customerId", order.getCustomerId() == null ? null : order.getCustomerId().toString());
        payload.put("paymentStatus", order.getPaymentStatus() == null ? null : order.getPaymentStatus().name());
        payload.put("orderStatus", order.getStatus() == null ? null : order.getStatus().name());
        payload.put("paymentMethod", order.getPaymentMethod());
        payload.put("paymentCode", order.getPaymentCode());
        payload.put("finalAmount", order.getFinalAmount());
        payload.put("paidAmount", order.getPaidAmount());
        payload.put("discountAmount", order.getDiscountAmount());
        payload.put("causationId", causationId);
        payload.put("occurredAt", Instant.now());

        return payload;
    }

    private Map<String, Object> buildHeaders(
            Order order,
            String eventId,
            String eventType,
            String businessKey,
            String topic,
            String causationId
    ) {
        Map<String, Object> headers = new LinkedHashMap<>();

        headers.put("source", SOURCE);
        headers.put("sourceService", SOURCE);
        headers.put("aggregateType", AGGREGATE_TYPE);
        headers.put("aggregateId", order.getId().toString());
        headers.put("eventId", eventId);
        headers.put("event_id", eventId);
        headers.put("eventType", eventType);
        headers.put("messageKey", order.getId().toString());
        headers.put("businessKey", businessKey);
        headers.put("topic", topic);
        headers.put("correlationId", order.getId().toString());
        headers.put("causationId", causationId);

        return headers;
    }

    private BigDecimal defaultZero(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }
}
