package org.hvtra.orderservice.integration.consumer;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "kafka-config", name = "enabled", havingValue = "true")
public class PaymentSucceededConsumer {

    private final PaymentSucceededInboxService paymentSucceededInboxService;

    @KafkaListener(
            topics = {
                    "${order.payment.events.topics.waiting:payment.waiting-payment}",
                    "${order.payment.events.topics.succeeded:payment.succeeded}",
                    "${order.payment.events.topics.failed:payment.failed}",
                    "${order.payment.events.topics.expired:payment.expired}",
                    "${order.payment.events.topics.cancelled:payment.cancelled}",
                    "${order.payment.events.topics.need-review:payment.need-review}"
            },
            groupId = "${spring.application.name:order-service}-payment-events"
//            containerFactory = "paymentEventKafkaListenerContainerFactory"
    )
    public void handle(ConsumerRecord<String, String> record, Acknowledgment acknowledgment) {
        paymentSucceededInboxService.handle(record);
        acknowledgment.acknowledge();
    }
}
