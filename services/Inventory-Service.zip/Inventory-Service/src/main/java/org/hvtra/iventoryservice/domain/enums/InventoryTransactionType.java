package org.hvtra.iventoryservice.domain.enums;

public enum InventoryTransactionType {
    STOCK_IN,
    SALE_OUT,
    RETURN_IN,
    ADJUSTMENT,
    TRANSFER
}
