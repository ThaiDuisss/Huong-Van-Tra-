package org.hvtra.iventoryservice.controller;

import jakarta.validation.Valid;
import org.hvtra.iventoryservice.dto.request.InventoryStatusRequest;
import org.hvtra.iventoryservice.dto.request.StoreShelfRequest;
import org.hvtra.iventoryservice.dto.response.InventoryLocationResponse;
import org.hvtra.iventoryservice.dto.response.PageResponse;
import org.hvtra.iventoryservice.domain.enums.InventoryStatus;
import org.hvtra.iventoryservice.service.StoreShelfService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;
import org.hvtra.iventoryservice.dto.response.LookupResponse;

@RestController
@RequestMapping("/api/inventory/inventory-locations/store")
public class StoreShelfController {

    private final StoreShelfService service;

    public StoreShelfController(StoreShelfService service) {
        this.service = service;
    }

    @GetMapping("/lookup")
    public PageResponse<LookupResponse> lookup(
            @RequestParam(name = "search", required = false) String search,
            @PageableDefault(size = 20, sort = "name") Pageable pageable) {
        return service.lookup(search, pageable);
    }

    @GetMapping
    public PageResponse<InventoryLocationResponse> findAll(
            @RequestParam(name = "query", required = false) String query,
            @RequestParam(name = "status", required = false) InventoryStatus status,
            @PageableDefault(size = 20, sort = "code") Pageable pageable) {
        return service.findAll(query, status, pageable);
    }

    @GetMapping("/{id}")
    public InventoryLocationResponse findById(@PathVariable("id") UUID id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public InventoryLocationResponse create(
            @Valid @RequestBody StoreShelfRequest request) {
        return service.create(request);
    }

    @PutMapping("/{id}")
    public InventoryLocationResponse update(
            @PathVariable("id") UUID id,
            @Valid @RequestBody StoreShelfRequest request) {
        return service.update(id, request);
    }

    @PatchMapping("/{id}/status")
    public InventoryLocationResponse updateStatus(
            @PathVariable("id") UUID id,
            @Valid @RequestBody InventoryStatusRequest request) {
        return service.updateStatus(id, request.status());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable("id") UUID id) {
        service.delete(id);
    }
}
