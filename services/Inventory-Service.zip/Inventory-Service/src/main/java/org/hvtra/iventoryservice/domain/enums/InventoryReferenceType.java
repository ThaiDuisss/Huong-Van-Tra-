package org.hvtra.iventoryservice.domain.enums;

public enum InventoryReferenceType {
    MANUAL,
    ORDER,
    RETURN_ORDER,
    STOCK_TRANSFER,
    STOCK_COUNT
}
