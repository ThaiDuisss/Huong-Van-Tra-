package org.hvtra.iventoryservice.domain.entity;

public class InventoryBatch {
}
